<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: index.html'); // Redirect to login page if not logged in
    exit();
}
?>




<!DOCTYPE html>

<!-- note most of my comments are at the styling sections :) -->

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta charset="utf-8" />
    <title>Orders</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="styles/styles.css" />
    <link rel="preload" href="styles.css" as="style" />
    <link rel="preload" href="scripts.js" as="script" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <script src="script.js" type="text/javascript"></script>
  </head>

  <body class="order-body">
    <main class="order-page">
    <header>
        <nav>
            <div>
                <img
                src="https://images.unsplash.com/photo-1516876437184-593fda40c7ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1172&q=80.png"
                />
                <h1>Burgir Bistro</h1>
            </div>

            <ul class="nav-center">
                <li><a href="index.php">Home</a></li>
                <li><a href="#about-us">About</a></li>
                <li><a href="#we-offer">We Offer</a></li>
                <li>
                    <a href="#" class="order">
                        <div class="order-tab"></div>
                        <p class="order-text">Order</p>
                    </a>
                </li>
            </ul>

            <div class="login-container">
                <div id="profile" class="profile-dropdown">
                    <img src="assests/cart.svg" class="cart" alt="Cart button" />
                    <div class="user-menu-button"><img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['username']); ?>&size=128&background=random&rounded=true&bold=true" alt="Profile Picture" class="profile-pic" />
                    <span><?php echo $_SESSION['username']; ?></span> </div>
                    <a href="logout.php" class="logout-button">Logout</a>
                </div>
            </div>

            <div class="toggle-btn">
                <i class="fa-solid fa-burger fa-xl"></i>
            </div>
        </nav>

        <div class="dropdown-menu">
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#about-us">About</a></li>
                <li><a href="#we-offer">We Offer</a></li>
                <li><a href="#locations">Locations</a></li>
            </ul>
        </div>
    </header>
    </main>

    <aside class="cart-items">
      <h1>x Items Added</h1>

      <div class="cart-body">
        <div class="cart-item-holder">
          <div class="cart-item-image">
            <img src="assests/burger1.png" alt="image of burgir" />
          </div>
          <div class="cart-item-desc">
            <h2>Fiery Inferno Burger</h2>
            <div class="cart-item-options">
              <img src="assests/trashcan.png" alt="trashcan" />
              <p>1</p>
              <button class="ease-transition">+</button>
              <p>20 AED</p>
            </div>
          </div>
        </div>
        <div class="cart-item-holder">
          <div class="cart-item-image">
            <img src="assests/burger1.png" alt="image of burgir" />
          </div>
          <div class="cart-item-desc">
            <h2>Fiery Inferno Burger</h2>
            <div class="cart-item-options">
              <img src="assests/trashcan.png" alt="trashcan" />
              <p>1</p>
              <button class="ease-transition">+</button>
              <p>20 AED</p>
            </div>
          </div>
        </div>
        <div class="cart-item-holder">
          <div class="cart-item-image">
            <img src="assests/burger1.png" alt="image of burgir" />
          </div>
          <div class="cart-item-desc">
            <h2>Fiery Inferno Burger</h2>
            <div class="cart-item-options">
              <img src="assests/trashcan.png" alt="trashcan" />
              <p>1</p>
              <button class="ease-transition">+</button>
              <p>20 AED</p>
            </div>
          </div>
        </div>
        <div class="cart-item-holder">
          <div class="cart-item-image">
            <img src="assests/burger1.png" alt="image of burgir" />
          </div>
          <div class="cart-item-desc">
            <h2>Fiery Inferno Burger</h2>
            <div class="cart-item-options">
              <img src="assests/trashcan.png" alt="trashcan" />
              <p>1</p>
              <button class="ease-transition">+</button>
              <p>20 AED</p>
            </div>
          </div>
        </div>
      </div>

      <div class="cart-total">
        <h2>20 AED</h2>
        <div class="ease-transition" style="cursor: pointer">
          <h2>View Cart</h2>
          <div class="circle">&gt</div>
        </div>
      </div>
    </aside>

    <div class="order-main">
      <nav class="order-nav">
        <ul>
          <li>Deals</li>
          <li class="active">Burgers</li>
          <li>Sides</li>
          <li>Drinks</li>
          <li>Desserts</li>
        </ul>
      </nav>

      <!-- <section class="menu-items">
        <div class="item"></div>
      </section> -->

      <section class="menu-items">
        <div class="menu-item">
          <div class="img-container">
            <img src="assests/burger1.png" alt="Gourmet Truffle Burger" />
          </div>
          <h2>Gourmet Truffle Burger</h2>
          <hr />
          <p>
            Elevate your burger experience with our Gourmet Truffle Burger, a
            luxurious treat for the senses.
          </p>
          <button class="add-to-cart button-animation">+ Add to Cart</button>
        </div>
        <div class="menu-item">
          <div class="img-container">
            <img src="assests/burger2.png" alt="Sizzlin' BBQ Burger" />
          </div>
          <h2>Sizzlin' BBQ Burger</h2>
          <hr />
          <p>
            Indulge in the mouthwatering Sizzlin' BBQ Burger, a true delight for
            BBQ lovers! Each bite leaving you craving for more.
          </p>
          <button class="add-to-cart button-animation">+ Add to Cart</button>
        </div>
        <div class="menu-item">
          <div class="img-container">
            <img src="assests/burger3.png" alt="Fiery Inferno Burger" />
          </div>
          <h2>Fiery Inferno Burger</h2>
          <hr />
          <p>
            Calling all spice enthusiasts! Brace yourself for a fiery
            masterpiece that will ignite your taste buds.
          </p>
          <button class="add-to-cart button-animation">+ Add to Cart</button>
        </div>
        <div class="menu-item">
          <div class="img-container">
            <img src="assests/burger1.png" alt="Gourmet Truffle Burger" />
          </div>
          <h2>Gourmet Truffle Burger</h2>
          <hr />
          <p>
            Elevate your burger experience with our Gourmet Truffle Burger, a
            luxurious treat for the senses.
          </p>
          <button class="add-to-cart button-animation">+ Add to Cart</button>
        </div>
        <div class="menu-item">
          <div class="img-container">
            <img src="assests/burger2.png" alt="Sizzlin' BBQ Burger" />
          </div>
          <h2>Sizzlin' BBQ Burger</h2>
          <hr />
          <p>
            Indulge in the mouthwatering Sizzlin' BBQ Burger, a true delight for
            BBQ lovers! Each bite leaving you craving for more.
          </p>
          <button class="add-to-cart button-animation">+ Add to Cart</button>
        </div>
        <div class="menu-item">
          <div class="img-container">
            <img src="assests/burger3.png" alt="Fiery Inferno Burger" />
          </div>
          <h2>Fiery Inferno Burger</h2>
          <hr />
          <p>
            Calling all spice enthusiasts! Brace yourself for a fiery
            masterpiece that will ignite your taste buds.
          </p>
          <button class="add-to-cart button-animation">+ Add to Cart</button>
        </div>
      </section>
    </div>

    <section style="height: 170vh"></section>

    <!-- <section class="our-classics" id="we-offer">
      <h1 class="main-header">Our Classics</h1>
      <hr class="header-underline" />
      <div class="flex1">
        <div>
          <img src="assests/burger1.png" alt="image of first burger" />
          <h3>Gourmet Truffle Burger</h3>

          <p>
            Elevate your burger experience with our Gourmet Truffle Burger, a
            luxurious treat for the senses.
          </p>
        </div>
        <div>
          <img src="assests/burger2.png" alt="image of second burger" />
          <h3>Sizzlin' BBQ Burger</h3>
          <p>
            Indulge in the mouthwatering Sizzlin' BBQ Burger, a true delight for
            BBQ lovers! Each bite leaving you craving for more.
          </p>
        </div>
        <div>
          <img src="assests/burger3.png" alt="image of third burger" />
          <h3>Fiery Inferno Burger</h3>
          <p>
            Calling all spice enthusiasts! Brace yourself for a fiery
            masterpiece that will ignite your taste buds.
          </p>
        </div>
      </div>
    </section> -->

    <!-- note most of my comments are at the styling sections :) -->

   

    <script>
      document.addEventListener("DOMContentLoaded", function () {
        // Get modal elements
        const modal = document.getElementById("login-modal");
        const loginBtn = document.getElementById("login-btn");
        const closeBtn = document.querySelector(".close");

        // Open modal when login button is clicked
        loginBtn.onclick = function () {
          modal.style.display = "flex";
          document.body.style.overflow = "hidden"; // Prevent scrolling when modal is open
        };

        // Close modal when close button is clicked
        closeBtn.onclick = function () {
          modal.style.display = "none";
          document.body.style.overflow = "auto"; // Re-enable scrolling when modal is closed
        };

        // Close modal when clicking outside of it
        window.onclick = function (event) {
          if (event.target == modal) {
            modal.style.display = "none";
            document.body.style.overflow = "auto"; // Re-enable scrolling when modal is closed
          }
        };
      });
    </script>
  </body>

  <script src="https://www.gstatic.com/dialogflow-console/fast/messenger/bootstrap.js?v=1"></script>
  <df-messenger
    
    chat-title="Burgir-Bistro"
    agent-id="ab285077-ec98-4b6d-ae48-828bfe421daa"
    language-code="en"
    style="position: relative; right: 20px"
  ></df-messenger>
  <!-- note most of my comments are at the styling sections :) -->
</html>
