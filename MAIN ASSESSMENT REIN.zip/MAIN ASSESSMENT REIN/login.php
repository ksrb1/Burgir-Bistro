<?php
session_start();
include 'db.php'; // Ensure this file correctly establishes the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        // Prepare a statement to avoid SQL injection
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            $error = 'SQL error.';
        } else {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if ($row = mysqli_fetch_assoc($result)) {
                // Assuming the password in the database is hashed
                if (password_verify($password, $row['password'])) {
                    // Login successful
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['userEmail'] = $row['email'];
                    header("Location: index.php");
                    exit();
                } else {
                    $error = 'Invalid email or password.';
                    header("Location: index.html");
                }
            } else {
                $error = 'No user found.';
                header("Location: index.html");
                
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Test</title>
</head>
<body>
    <h2>Login to Test Application</h2>
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <form action="login.php" method="POST">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
        <br>
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
        <br>
        <button type="submit">Login</button>
    </form>
</body>
</html>
